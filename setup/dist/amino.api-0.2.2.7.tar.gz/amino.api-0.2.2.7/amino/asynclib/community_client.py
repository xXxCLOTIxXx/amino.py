from .client import Client


class CommunityClient(Client):
	def __init__(self):
		Client.__init__(self)