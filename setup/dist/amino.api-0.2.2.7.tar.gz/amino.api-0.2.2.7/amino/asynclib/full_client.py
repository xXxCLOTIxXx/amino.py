from .client import Client

class FullClient(Client):

	def __init__(self):
		Client.__init__(self)